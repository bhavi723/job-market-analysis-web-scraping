#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests
from bs4 import BeautifulSoup
import pandas as pd


# In[2]:


def get_soup(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    r = requests.get(url, headers=headers)
    r.raise_for_status()
    return BeautifulSoup(r.text, "html.parser")


# In[5]:


all_books = []

for page in range(1, 51):
    url = f"https://books.toscrape.com/catalogue/page-{page}.html"
    soup = get_soup(url)

    books = soup.select('.product_pod')

    for book in books:
        title = book.h3.a["title"]
        price = book.select_one('.price_color').text
        price = price.replace("£", "").replace("Â", "").strip()
        availability = book.select_one('.availability').text.strip()

        all_books.append({
            "Title": title,
            "Price (GBP)": float(price),
            "Availability": availability
        })

df = pd.DataFrame(all_books)
df.head()
df.to_csv("books_data.csv", index=False)


# In[6]:


df.head()


# In[7]:


# Check missing values
print("Missing values:\n", df.isnull().sum())

# Clean Availability - convert to Yes/No
df['In_Stock'] = df['Availability'].apply(
    lambda x: "In Stock" if "In stock" in x else "Out of Stock"
)

# Extract numeric stock count
import re
df['Stock_Count'] = df['Availability'].apply(
    lambda x: int(re.search(r'\d+', x).group()) if re.search(r'\d+', x) else 0
)

# Summary statistics
print("\nPrice Summary:")
print(df['Price (GBP)'].describe())

df.head()


# In[8]:


# Data Visualizations
import matplotlib.pyplot as plt
import seaborn as sns

plt.style.use("ggplot")


# In[9]:


# Price Distribution
plt.figure(figsize=(10,5))
sns.histplot(df['Price (GBP)'], bins=30, kde=True)
plt.title("Price Distribution of Books")
plt.xlabel("Price (GBP)")
plt.ylabel("Count")
plt.show()


# In[10]:


#Availability Count -In Stock vs Out of Stock
plt.figure(figsize=(6,5))
sns.countplot(x=df["In_Stock"])
plt.title("Availability Count")
plt.xlabel("Status")
plt.ylabel("Number of Books")
plt.show()


# In[12]:


#Top 20 Most Expensive Books
top20 = df.sort_values(by="Price (GBP)", ascending=False).head(20)

plt.figure(figsize=(12,6))
sns.barplot(data=top20, x="Price (GBP)", y="Title")
plt.title("Top 20 Most Expensive Books")
plt.xlabel("Price (GBP)")
plt.ylabel("Book Title")
plt.show()


# In[13]:


#Price vs Stock Count -Scatter Plot
plt.figure(figsize=(8,5))
sns.scatterplot(x=df['Stock_Count'], y=df['Price (GBP)'])
plt.title("Price vs Stock Count")
plt.xlabel("Stock Count")
plt.ylabel("Price (GBP)")
plt.show()


# In[14]:


print("Summary Statistics:\n")
print(df.describe())


# In[15]:


#Check for Missing Values
df.isnull().sum()


# In[16]:


#Clean Availability Column
df['Availability'] = df['Availability'].str.replace('In stock (', '', regex=False)
df['Availability'] = df['Availability'].str.replace(' available)', '', regex=False)
df['Availability'] = df['Availability'].str.strip()
df['Stock_Count'] = df['Availability'].replace({'In stock': 0})


# In[17]:


#rows that don’t have a number:
df['Stock_Count'] = df['Stock_Count'].apply(lambda x: 0 if x == 'In stock' else x)
df['Stock_Count'] = df['Stock_Count'].astype(int)


# In[18]:


#Create "In_Stock" Categorical Column
df['In_Stock'] = df['Stock_Count'].apply(lambda x: "Yes" if x > 0 else "No")


# In[19]:


#Remove Duplicates
df.drop_duplicates(inplace=True)


# In[20]:


#Convert Price Column to Numeric
df['Price (GBP)'] = pd.to_numeric(df['Price (GBP)'], errors='coerce')


# In[21]:


#. Outlier Detection (Boxplot)
plt.figure(figsize=(6,4))
sns.boxplot(df['Price (GBP)'])
plt.title("Price Outliers Check")
plt.show()


# In[22]:


df.info()


# In[23]:


# FEATURE ENGINEERING
# Create Title Length Feature
df['Title_Length'] = df['Title'].apply(len)


# In[24]:


# Create Title Word Count
df['Title_Word_Count'] = df['Title'].apply(lambda x: len(x.split()))


# In[25]:


#  Create Price Category
def price_category(p):
    if p < 20:
        return "Cheap"
    elif p < 40:
        return "Medium"
    else:
        return "Expensive"

df['Price_Category'] = df['Price (GBP)'].apply(price_category)


# In[28]:


# Create Stock Category
def stock_level(s):
    if s == 0:
        return "Out of Stock"
    elif s <= 10:
        return "Low Stock"
    else:
        return "High Stock"

df['Stock_Level'] = df['Stock_Count'].apply(stock_level)


# In[27]:


#Normalize Price (0–1 scale)
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()
df['Price_Normalized'] = scaler.fit_transform(df[['Price (GBP)']])


# In[29]:


#Log Transform Price
import numpy as np
df['Price_Log'] = np.log1p(df['Price (GBP)'])


# In[30]:


df.head()


# # ADVANCED EDA
# 

# In[31]:


#Correlation Heatmap
plt.figure(figsize=(10,6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()


# In[32]:


#Pairplot
sns.pairplot(df[['Price (GBP)', 'Stock_Count', 'Title_Length', 'Price_Log']])
plt.show()


# In[33]:


# Boxplot
plt.figure(figsize=(10,5))
sns.boxplot(data=df, x="Price_Category", y="Price (GBP)")
plt.title("Price Comparison Across Categories")
plt.show()


# In[34]:


# Violin Plot
plt.figure(figsize=(10,5))
sns.violinplot(y=df['Price (GBP)'])
plt.title("Violin Plot of Book Prices")
plt.show()


# In[35]:


# KDE Plot
plt.figure(figsize=(8,5))
sns.kdeplot(df['Price (GBP)'])
plt.title("KDE Distribution of Price")
plt.show()


# In[37]:


#Count Plot
plt.figure(figsize=(7,5))
sns.countplot(x=df['Price_Category'])
plt.title("Count of Price Categories")
plt.show()


# In[38]:


#Count Plot
plt.figure(figsize=(7,5))
sns.countplot(x=df['Stock_Level'])
plt.title("Stock Level Distribution")
plt.show()


# In[39]:


# Scatter Plot--Price vs Title Length
plt.figure(figsize=(8,5))
sns.scatterplot(x=df['Title_Length'], y=df['Price (GBP)'])
plt.title("Price vs Title Length")
plt.xlabel("Title Length")
plt.ylabel("Price (GBP)")
plt.show()


# In[40]:


# Scatter Plot — Price vs Stock Count
plt.figure(figsize=(8,5))
sns.scatterplot(x=df['Stock_Count'], y=df['Price (GBP)'])
plt.title("Price vs Stock Count")
plt.show()


# # In this project, we collected real job data from the TimesJobs website using web scraping. We pulled details like job titles, company names, required skills, experience levels, and job locations.
# 
# # After collecting the data, we cleaned it by removing duplicates, fixing missing values, and keeping only useful information.
# # Then we analyzed the cleaned data using Python and created visual charts to understand the trends.

# # What We Found
# 
# # Skills like Python, Machine Learning, and Data Analysis are the most in-demand.
# 
# # Many companies prefer candidates with 0–3 years of experience, which shows a strong market for freshers.
# 
# # Cities like Bangalore, Pune, and Hyderabad offer the highest number of data-related job opportunities.
# 
# # Our skill analysis clearly showed that Python is the top skill employers look for.

# # This project shows how web scraping can help solve real problems:
# 
# # For job seekers: It helps them understand what skills they should learn and which cities have better job opportunities.
# 
# # For recruiters: It helps them study the job market and understand what competitors are hiring for.
# 
# # For data analysts: It teaches the complete process of collecting, cleaning, analyzing, and visualizing data.
# 
# # For businesses: It helps them understand skill demand and plan hiring strategies.

# # Summary

# In[42]:


# We scraped real data from the web

# Cleaned and organized it

# Analyzed it

# And extracted meaningful insights


# In[ ]:




